using TRES0002K

cfg = BenchmarkConfig(100_000, 8, 1, 8, SEED)
state = initialize_state(cfg)
validate_state(state)
start_ns = time_ns()
result = churn!(state)
elapsed_ms = (time_ns() - start_ns) / 1.0e6
validate_state(state)
println("operations=", result.operations)
println("deactivated=", result.deactivated)
println("reweighted=", result.reweighted)
println("created=", result.created)
println("relation_count=", result.relation_count)
println("active_index_count=", result.active_index_count)
println("batch_ms=", elapsed_ms)
