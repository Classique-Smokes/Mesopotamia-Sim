using TRES0002K

const CASES = Dict(
    "P1" => BenchmarkConfig(10_000, 8, 1, 8, SEED),
    "P2" => BenchmarkConfig(100_000, 8, 1, 8, SEED),
    "P3" => BenchmarkConfig(100_000, 16, 5, 8, SEED),
    "P4" => BenchmarkConfig(300_000, 16, 5, 32, SEED),
)

function status_kib(field::String)
    path = "/proc/self/status"
    isfile(path) || return nothing
    prefix = field * ":"
    for line in eachline(path)
        startswith(line, prefix) || continue
        parts = split(line)
        length(parts) >= 2 || return nothing
        return parse(Int, parts[2])
    end
    return nothing
end

function phase_ms(start_ns::UInt64)
    return Float64(time_ns() - start_ns) / 1.0e6
end

function one_run(cfg::BenchmarkConfig)
    GC.gc()
    checkpoint_path = tempname()

    t = time_ns()
    state = initialize_state(cfg)
    init_ms = phase_ms(t)

    t = time_ns()
    proposals = decide(state)
    decision_ms = phase_ms(t)

    t = time_ns()
    accepted = commit!(state, proposals)
    commit_ms = phase_ms(t)

    t = time_ns()
    schedule_processes!(state, accepted)
    schedule_ms = phase_ms(t)

    t = time_ns()
    write_checkpoint(checkpoint_path, state)
    checkpoint_write_ms = phase_ms(t)
    checkpoint_size_bytes = filesize(checkpoint_path)

    t = time_ns()
    execute_processes!(state)
    execute_ms = phase_ms(t)

    t = time_ns()
    hash = canonical_hash(state)
    hash_ms = phase_ms(t)
    validate_state(state)

    proposal_count = length(proposals)
    accepted_count = length(accepted)
    event_count = length(state.events)

    # Drop the uninterrupted state before loading the checkpoint. Otherwise a
    # process high-water RSS observation would include two full copies of the
    # simulation merely because this harness verifies both paths.
    state = nothing
    proposals = nothing
    accepted = nothing
    GC.gc()

    # Same-runtime restore measurement. The separate verify_fresh_restore.sh
    # script is the strict fresh-runtime correctness path.
    t = time_ns()
    restored = read_checkpoint(checkpoint_path)
    checkpoint_load_ms = phase_ms(t)

    t = time_ns()
    execute_processes!(restored)
    restored_execute_ms = phase_ms(t)

    t = time_ns()
    restored_hash = canonical_hash(restored)
    restored_hash_ms = phase_ms(t)
    hash == restored_hash || error("restored benchmark continuation diverged")

    rm(checkpoint_path; force=true)
    validate_state(restored)

    return (
        init_ms=init_ms,
        decision_ms=decision_ms,
        commit_ms=commit_ms,
        schedule_ms=schedule_ms,
        checkpoint_write_ms=checkpoint_write_ms,
        execute_ms=execute_ms,
        hash_ms=hash_ms,
        checkpoint_load_ms=checkpoint_load_ms,
        restored_execute_ms=restored_execute_ms,
        restored_hash_ms=restored_hash_ms,
        proposals=proposal_count,
        accepted=accepted_count,
        events=event_count,
        checkpoint_size_bytes=checkpoint_size_bytes,
        final_hash=hash,
        restored_hash=restored_hash,
    )
end

function median3(values::Vector{Float64})
    length(values) == 3 || error("median3 requires exactly three values")
    sorted = sort(copy(values))
    return sorted[2]
end

function print_run(prefix::String, result)
    for name in propertynames(result)
        println(prefix, ".", name, "=", getproperty(result, name))
    end
end

length(ARGS) >= 1 || error("usage: benchmark_case.jl P1|P2|P3|P4 [warm_repetitions=3]")
case_name = uppercase(ARGS[1])
haskey(CASES, case_name) || error("unknown case $case_name")
warm_repetitions = length(ARGS) >= 2 ? parse(Int, ARGS[2]) : 3
warm_repetitions >= 1 || error("warm repetitions must be >= 1")
cfg = CASES[case_name]

println("case=", case_name)
println("threads=", Threads.nthreads())
Threads.nthreads() == 1 || error("baseline benchmark must run with one Julia thread")
println("n=", cfg.n)
println("d=", cfg.d)
println("active_percent=", cfg.active_percent)
println("candidate_limit=", cfg.candidate_limit)

# First invocation on a fresh Julia process is the cold/JIT-affected observation.
cold = one_run(cfg)
print_run("cold", cold)

warm = Any[]
for rep in 1:warm_repetitions
    push!(warm, one_run(cfg))
end
for (rep, result) in pairs(warm)
    print_run("warm$(rep)", result)
end

if warm_repetitions == 3
    timing_fields = (
        :init_ms,
        :decision_ms,
        :commit_ms,
        :schedule_ms,
        :checkpoint_write_ms,
        :execute_ms,
        :hash_ms,
        :checkpoint_load_ms,
        :restored_execute_ms,
        :restored_hash_ms,
    )
    for field in timing_fields
        values = Float64[getproperty(result, field) for result in warm]
        println("warm_median.", field, "=", median3(values))
        println("warm_min.", field, "=", minimum(values))
        println("warm_max.", field, "=", maximum(values))
    end
end

rss = status_kib("VmRSS")
hwm = status_kib("VmHWM")
println("final_rss_bytes=", rss === nothing ? "unavailable" : rss * 1024)
println("process_peak_rss_bytes=", hwm === nothing ? "unavailable" : hwm * 1024)
