using TRES0002K

length(ARGS) == 1 || error("usage: write_fixture_checkpoint.jl CHECKPOINT_PATH")
path = ARGS[1]
cfg = BenchmarkConfig(1000, 8, 5, 8, SEED)
state, proposals, accepted = run_until_checkpoint(cfg)
length(proposals) == 50 || error("fixture proposal count mismatch")
length(accepted) == 45 || error("fixture accepted count mismatch")
length(state.processes) == 45 || error("fixture process count mismatch")
write_checkpoint(path, state)
println("checkpoint=", abspath(path))
println("checkpoint_semantic_hash=", canonical_hash(state))
